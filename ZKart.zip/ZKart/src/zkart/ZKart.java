package zkart;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class ZKart {
    
    private static void registerUser() {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter Your mail ID");
        String uname=s.next();
        System.out.println("Enter Your password");
        String password=s.next();
        System.out.println("Enter Your name");
        String name=s.next();
        System.out.println("Enter Your mobile no");
        String mobileno=s.next();
        /*try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/jdbc","root","");
            Statement smt=cn.createStatement();
            String q="Select * from student where sub1>80 and sub2>80 and sub4>80 and sub3>80";
            ResultSet rs=smt.executeQuery(q);
            while(rs.next())
            {
                System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6));
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }*/
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/zkart?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=Europe/Berlin","root","");
           // Statem/ent ps=con.createStatement();
           
                //Statement ps = con.createStatement();
                PreparedStatement ps;
                ps=con.prepareStatement("Insert into users(uname,password,name,mobileno) values(?,?,?,?)");
                ps.setString(1, uname);
                ps.setString(2, password);
                ps.setString(3, name);
                ps.setString(4, mobileno);
                
                int r=ps.executeUpdate();
                /*if(r>0)
                {
                //} else {
                    JOptionPane.showMessageDialog(null, "New User Added");
            } */ 
                if(r>0)
                {
                    System.out.println("Registered Successfully!");
                }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int ch;
        //System.out.println("What task you would like to perform" +"\n" +"1.Register for new user." +"\n"+ "2.login" +"\n"+"3.Shopping"+"\n"+"4.Admin"+"\n"+"5.order history");
        do
        {
            System.out.println("What task you would like to perform" +"\n" +"1.Register for new user." +"\n"+ "2.login" +"\n"+"3.Admin");
            System.out.println("What would you like to do?");
        int n=sc.nextInt();
        switch(n)
        {
            case 1:registerUser();
                break;
            case 2:login();
                break;
          // case 3:shopping();
            //break;
           case 3:admin();
            break;
            
        }
        
        System.out.println("Enter 0 to exit other numbers to continue");
        ch=sc.nextInt();
        }while(ch!=0);
    }

    private static void login() {
    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Scanner s=new Scanner(System.in);
        System.out.println("Enter Your mail ID");
        String uname=s.next();
        System.out.println("Enter Your password");
        String password=s.next();
        int c;
        
        try {
            /*
            Connection con = MyConnection.getConnection();
            PreparedStatement ps;
            
            try {
                ps=con.prepareStatement("SELECT * FROM  user WHERE username=? AND password=?");
                ps.setString(1,txt_user.getText());
                ps.setString(2,String.valueOf(jPasswordField1.getPassword()));
                
                ResultSet rs=ps.executeQuery();

            */
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/zkart?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=Europe/Berlin","root","");
            PreparedStatement ps;
            ps=con.prepareStatement("Select * from users where uname=? and password=?");
            ps.setString(1, uname);
            ps.setString(2,password);
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
                System.out.println("You are logged in");
                do
                {
    
                System.out.println("What you like to do?1.Shopping 2.Your order details 3.View existing products");
                int ch=s.nextInt();
                switch(ch)
                {
                    case 1:shopping(uname);
                        break;
                    case 2:orderDetails(uname);
                        break;
                    case 3:Viewproducts();
                    break;
                        
                }
                System.out.println("Enter 0 to  logout or other numbers to continue with shopping");
                c=s.nextInt();
                }while(c!=0);
            } 
            else
            {
                System.out.println("Invalid user");
            }
            
        } catch (Exception ex) {
            System.out.println(ex);
        }
          
    }

    private static void shopping(String uname) {
       //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println("What you would like to order?");
        Scanner s=new Scanner(System.in);   
        String thing=s.next();
        System.out.println("Enter brand");
        String brand=s.next();
        System.out.println("Enter model");
        String model=s.next();
        System.out.println("How many products you would like to purchase");
        int n=s.nextInt();
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/zkart?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=Europe/Berlin","root","");
            PreparedStatement ps;
            ps=con.prepareStatement("Select * from inventory where caegory=? and brand=? and model=?");
            ps.setString(1, thing);
            ps.setString(2,brand);
            ps.setString(3,model);
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
                int price=rs.getInt(4);
                int t=rs.getInt(5);
                //System.out.println("Stock"+t);
                if(t>n)
                {
                    //ps=con.prepareStatement()
                    try {
                        int m=t-n;
                        PreparedStatement psi;
                psi = con.prepareStatement("UPDATE inventory SET stock=? where caegory=? and brand=? and model=?");
                psi.setInt(1,m);
                psi.setString(2, thing);
                psi.setString(3,brand);
                psi.setString(4,model);
                psi.executeUpdate();
                psi=con.prepareStatement("insert into orderdetails values(?,?,?,?,?)");
                psi.setString(1,thing);
                psi.setString(2,brand);
                psi.setString(3,model);
                psi.setInt(4,price);
                psi.setString(5, uname);
                psi.executeUpdate();
                System.out.println("Order placed successfully!");
            } catch (Exception ex) {
               System.out.println(ex);
            }
            }
                
            }
            else
                {
                    System.out.println("order can't to be placed at this moment");
                }
            
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
    }

    private static void admin() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Scanner s=new Scanner(System.in); 
        String name="admin@zoho.com";
        String pass="xyzzy";
        System.out.println("Enter user name");
        String n=s.next();
        System.out.println("Enter password");
        String p=s.next();
        if(n.equals(name) && p.equals(pass))
        {
        System.out.println("What you like to do?1.Make order 2.Your order details 3.AddNewproduct");
            int ch=s.nextInt();
            switch(ch)
            {
                case 1:MakeOrder();
                break;
                case 2:ViewStock();
                break;
                case 3:AddnewProduct();
                break;
                        
            }
    }
        else
        {
            System.out.println("Sorry! Invalid user");
        }
    }
    private static void orderDetails(String uname) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        PreparedStatement ps;
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/zkart?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=Europe/Berlin","root","");
            
            ps=con.prepareStatement("SELECT * FROM orderdetails where user=?");
            ps.setString(1, uname);
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {
                System.out.print("Category:"+rs.getString(1));
                System.out.print("  brand:"+rs.getString(2));
                System.out.print("  model:"+rs.getString(3));
                System.out.print("  price:"+rs.getInt(4));
                //System.out.println:"+rs.getInt(5));
            }
          // table.setVisible(true); 
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    private static void MakeOrder() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        System.out.println("What you would like to order?");
        Scanner s=new Scanner(System.in);   
        String thing=s.next();
        System.out.println("Enter brand");
        String brand=s.next();
        System.out.println("Enter model");
        String model=s.next();
        System.out.println("How many products you would like to purchase");
        int n=s.nextInt();
        
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/zkart?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=Europe/Berlin","root","");
            PreparedStatement ps;
            int m = 0;
            ps=con.prepareStatement("Select * from inventory where caegory=? and brand=? and model=?");
            ps.setString(1, thing);
            ps.setString(2,brand);
            ps.setString(3,model);
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
            m=rs.getInt(5);
            }
            PreparedStatement psi;
            
                psi = con.prepareStatement("UPDATE inventory SET stock=? where caegory=? and brand=? and model=?");
                psi.setInt(1,m+n);
                psi.setString(2, thing);
                psi.setString(3,brand);
                psi.setString(4,model);
                psi.executeUpdate();
                
            } catch (Exception ex) {
               System.out.println(ex);
            }
      }
//}
        
//    }

    private static void ViewStock(){
    //    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        //JTable table=new JTable();
        PreparedStatement ps;
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/zkart?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=Europe/Berlin","root","");
            
            ps=con.prepareStatement("SELECT * FROM inventory");
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {
                System.out.print("Category:"+rs.getString(1));
                System.out.print("  brand:"+rs.getString(2));
                System.out.print("  model:"+rs.getString(3));
                System.out.print("  price:"+rs.getInt(4));
                System.out.println("    stock:"+rs.getInt(5));
            }
          // table.setVisible(true); 
        } catch (Exception ex) {
            System.out.println(ex);
        }
        

    }

    private static void AddnewProduct() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Scanner s=new Scanner(System.in);
        System.out.println("Enter product category");
        String cat=s.next();
        System.out.println("Enter product brand");
        String brand=s.next();
        System.out.println("Enter product model");
        String model=s.next();
        System.out.println("Enter product price");
        int p=s.nextInt();
        System.out.println("Enter number of product");
        int n=s.nextInt();
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/zkart?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=Europe/Berlin","root","");
           // Statem/ent ps=con.createStatement();
           
                //Statement ps = con.createStatement();
                PreparedStatement ps;
                ps=con.prepareStatement("Insert into inventory values(?,?,?,?,?)");
                ps.setString(1, cat);
                ps.setString(2, brand);
                ps.setString(3, model);
                ps.setInt(4, p);
                ps.setInt(5,n);
                
                int r=ps.executeUpdate();
                /*if(r>0)
                {
                //} else {
                    JOptionPane.showMessageDialog(null, "New User Added");
            } */ 
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    private static void Viewproducts() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        PreparedStatement ps;
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/zkart?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=Europe/Berlin","root","");
            
            ps=con.prepareStatement("SELECT * FROM inventory");
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {
                System.out.print("Category:"+rs.getString(1));
                System.out.print("  brand:"+rs.getString(2));
                System.out.print("  model:"+rs.getString(3));
                System.out.print("  price:"+rs.getInt(4));
                System.out.println("    stock:"+rs.getInt(5));
            }
          // table.setVisible(true); 
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
    }
    
    
}
